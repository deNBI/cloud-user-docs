curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.5/install.sh | bash
nvm install 8
npm install -g yarn
yarn
yarn theia build
